package gestion;

@SuppressWarnings("serial")
public class HoraireIncorrect extends Exception{
	
	public HoraireIncorrect(String message) {
		super(message);
	}
}
