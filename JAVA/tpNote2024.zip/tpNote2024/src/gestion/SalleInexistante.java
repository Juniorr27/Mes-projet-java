package gestion;

@SuppressWarnings("serial")
public class SalleInexistante extends Exception {
	public SalleInexistante(String message) {
		super(message);
	}
}
