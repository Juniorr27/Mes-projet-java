
module tpNote2024 {
	requires org.junit.jupiter.api;
}